# Travellist - Laravel Demo App

This is a Laravel 6 demo application to support our Laravel guides.
